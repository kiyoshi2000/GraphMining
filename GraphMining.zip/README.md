# Graph Mining Project

This project explores and analyzes two real-world graphs using classic techniques from graph theory and network science, including centrality measures, community detection, and node embeddings. All analyses are implemented in Python and organized in two Jupyter notebooks.

## Notebooks

### 1. `DrugInteraction.ipynb`
- **Nodes:** Drugs  
- **Edges:** Two drugs are connected if one alters the effect of the other.
- **Analysis:**  
  - Centrality measures (degree, betweenness, etc.)
  - Community detection
  - Node embeddings (e.g. Node2Vec, Spectral)
  - Interpretation of the drug interaction network's structure

### 2. `DeveloperSocialNetworks.ipynb`
- **Nodes:** Developers  
- **Edges:** Follower relationships (directed)
- **Labels:** Each developer is labeled as either a **Web Developer** or **ML Developer**.
- **Analysis:**  
  - Centrality and influence in the network
  - Community structure
  - Comparison of node embeddings
  - Evaluation of how well structural features align with developer type

## Requirements

All dependencies are listed in the `requirements.txt` file. You can install them with:

```bash
pip install -r requirements.txt